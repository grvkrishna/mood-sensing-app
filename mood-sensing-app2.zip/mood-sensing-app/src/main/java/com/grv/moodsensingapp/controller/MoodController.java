package com.grv.moodsensingapp.controller;


import com.grv.moodsensingapp.dtos.MoodFrequency;
import com.grv.moodsensingapp.dtos.UserMood;
import com.grv.moodsensingapp.services.MoodService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("v1/mood")
public class MoodController {


    @Autowired
    MoodService moodService;

    @PostMapping("/")
    @ResponseStatus(HttpStatus.CREATED)
    public UserMood  storeUserMood(@Valid @RequestBody UserMood uMood){
        moodService.userMoodStore(uMood);
        return uMood;
    }

    @GetMapping("/{name}")
    public MoodFrequency getMoodFrequency(@PathVariable("name") String uName){
      return   moodService.getMoodFrequncy(uName);
    }


    @GetMapping("/{name}/{longitude}/{latitude}")
    public UserMood getNearestHappyLoc(@PathVariable("name") String uName,
                                       @PathVariable("longitude") Double longitude,
                                       @PathVariable("latitude") Double latitude){

       return moodService.getNearesHappyLocation(uName,longitude,latitude);
    }
}
