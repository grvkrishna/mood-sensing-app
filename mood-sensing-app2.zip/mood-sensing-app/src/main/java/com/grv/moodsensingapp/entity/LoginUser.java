package com.grv.moodsensingapp.entity;

import java.util.List;

public class LoginUser {

    private String username;
    private String password;

    private List<String> rolse;
}
