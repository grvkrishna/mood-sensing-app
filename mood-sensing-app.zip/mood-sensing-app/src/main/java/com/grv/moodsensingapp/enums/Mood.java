package com.grv.moodsensingapp.enums;

public enum Mood {
    happy,sad,neutral
}
