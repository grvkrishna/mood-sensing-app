# Mood Sensing App


## Background:

We are creating backend for mood sensing app, here we will have user ,mood and location of user.

## Stack :

    Spring boot.
    Mongo db.
    java 17

## Data Model:

```json
{
  "user_name": "",
  "mood": "",
  "location": {
        "type": "points",
        "coordinates": [
            longitude,
            latitude
          ]
      }
}
   ```
<!-- TOC -->
    User Name : Required a nd alphanumeric.
    Mood:  required and enum value {happy, sad, neutral}
    Location : required and geolocation of user while uploading mood. Need to create index in mongo with “2dsphere“.
<!-- TOC -->


## Low leve spec:

| Operation                                                                    | Note |
|------------------------------------------------------------------------------|------|
| Upload a mood given for user and location.                                   |  Store user information with mood and location in database.    |
| Return mood frequency for given user.                                        |    This end point will return user’s mood counts with respective of all moods.
|
| Given user’s current location , return closest location where user is happy. | With input of user and location return closes location where user is happy.



## Api Details:
<!-- TOC -->
 ## 1. Store mood:
    Request Type: POST 
    URL : /mood/
    Payload :
                {
                    “name“: ““,
                    “mood“: ““,
                    location: [
                            longitude,
                            latitude
                        ]
                }

    Response Status : 201
    Respnse Body : {
                        “id“: “““name“: ““,
                        “mood“: ““,
                        location: [
                            longitude,
                            latitude
                            ]
                    }
        
## 2. Get Mood frequency:
    Request Type: GET
    URL : /mood/{name}
    Request Body: 
    Response Status : 200
    Response Body: {
                        "Sad": count,
                        "Happy": count,
                        "Neutral": count
                    }

## 3. Get Nearest Happy location:
    Request Type : GET
    URL: /mood/{name}/{longitude}/{latitude}
    Request Body: 
    Respnse Status: 200
    Response Body: {
                    "location": [
                        longitude,
                        latitude
                    ],
                    "mood": happy
                    }
<!-- TOC -->

