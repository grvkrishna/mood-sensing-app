package com.grv.moodsensingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoodSensingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
