package com.grv.moodsensingapp.testentity;

public class UserMoodTestEntity {
}
